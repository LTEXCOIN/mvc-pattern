<?php
require_once '../vendor/autoload.php';

use app\core\Application;
new Application();
