<?php


namespace app\core\validator;


class Form
{
    public function __construct()
    {

    }
}