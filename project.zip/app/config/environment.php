<?php
namespace app\config;

define('MVC_DEBUG', 1);
define('APP_URL',   'http://localhost/mvc/');